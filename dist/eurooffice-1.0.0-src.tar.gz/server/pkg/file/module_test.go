/**
 *
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package file

import (
	"testing"

	"github.com/stretchr/testify/require"
	"go.uber.org/fx"
	"go.uber.org/fx/fxtest"

	"github.com/ONLYOFFICE/onlyoffice-mattermost/public"
)

func TestFileModuleProvidesFileHelper(t *testing.T) {
	formatManager, err := public.NewMapFormatManager()
	require.NoError(t, err)

	var helper Helper
	app := fxtest.New(t,
		fx.NopLogger,
		fx.Provide(func() public.FormatManager { return formatManager }),
		Module,
		fx.Populate(&helper),
	)

	app.RequireStart().RequireStop()

	require.NotNil(t, helper)
	require.True(t, helper.IsExtensionSupported("docx"))
}
