/**
 *
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package callback

import (
	"errors"
	"fmt"
)

var ErrHandlerAlreadyRegistered = errors.New(onlyofficeLoggerCallbackPrefix + "handler with this code has already been registered")
var ErrInvalidUserID = errors.New(onlyofficeLoggerCallbackPrefix + "invalid callback user")
var ErrHTTPClientRequired = errors.New(onlyofficeLoggerCallbackPrefix + "http client is required")

type FilePersistenceError struct {
	FileID string
	Reason string
}

func (e *FilePersistenceError) Error() string {
	return fmt.Sprintf(onlyofficeFilePersistenceErrorPrefix+"file %s could not be saved: %s", e.FileID, e.Reason)
}

type FileNotFoundError struct {
	FileID string
	Reason string
}

func (e *FileNotFoundError) Error() string {
	return fmt.Sprintf(onlyofficeLoggerCallbackPrefix+"file %s not found: %s", e.FileID, e.Reason)
}

type InvalidFileDownloadURLError struct {
	FileID string
}

func (e *InvalidFileDownloadURLError) Error() string {
	return fmt.Sprintf(onlyofficeLoggerCallbackPrefix+"could not find a callback file %s url", e.FileID)
}

type HandlerDoesNotExistError struct {
	Code int
}

func (e *HandlerDoesNotExistError) Error() string {
	return fmt.Sprintf(onlyofficeLoggerCallbackPrefix+"callback handler for code (%d) does not exist", e.Code)
}
