# Change Log

## 2.4.1
## Fixed
- requests now get proxied via `HTTP_PROXY`, `HTTPS_PROXY` and `NO_PROXY`
- partial configuration saves no longer drop plugin settings
- unknown formats in settings are ignored and logged instead of failing activation

## 2.4.0
### Added
- `Allow private Document Server address` setting (`DESAllowPrivate`)

### Changed
- loopback and private-network Document Server addresses are now rejected by default, including redirect hops
- stricter Document Server URL sanitizing
- updated dependencies

### Fixed
- outgoing requests no longer fall back to the default http client

## 2.3.0
### Added
- configuration flag to toggle health-check notifications.
- live view support

### Changed
- disabled administrator notifications by default.
- modern light/dark themes
- refresh editor on outdated file version
- updated dependencies.

## 2.2.0
### Added
- user mentions via Mattermost bot
- periodic health-checks for document server
- plugins, macros and protection flags in settings

### Changed
- updated copyrights
- updated dependencies

### Fixed
- webapp websocket notifications
- disabled chat by default
- fixed real-time extensions issue

## 2.1.0
### Added
- selectable file extensions for opening documents in the editor

## Changed
- replace `open file location` with `close`

### Fixed
- fixed `shardkey` query parameter in API.js

## 2.0.0
## Added
- support for new document formats
- conversion to OOXML format
- manual XML conversion to document/spreadsheet
- conversion of protected documents
- document creation via new upload option
- demo server support
- onyx and Indigo theme support (including editor support)

## Changed
- refactored server to use fx modules
- replaced formats service with formats submodule
- added empty document templates submodule
- updated document icons
- improved shard key generation for document editors
- enhanced configuration validation
- updated permissions window styles

## Fixed
- general optimization and bug fixes

## 1.2.0
## Added
- support mattermost v9 and v10

## Changed
- fixed styles
- dependency bump for enhanced security

## 1.1.3
## Added
- link to docs cloud

## Changed
- update of vulnerable dependencies

## 1.1.2
## Changed
- update JWT lib

## 1.1.1
## Changed
- fix work with s3 bucket
- editor loader fix
- dependency update

## 1.1.0
## Added
- support mattermost v6 and v7

## 1.0.1
## Added
- disable certificate verification
- warning in the settings about downloading and executing the code of the editors

## Changed
- improved JWT validation

## 1.0.0
## Added
- config page for urls and JWT settings
- file sharing for editing
- coediting docx, xlsx, pptx
- viewing xls, xlsx, csv, xlsm, xlt, xltm, ods, fods, ots, pps, ppsx, ppsm, ppt, pptx, pptm, pot, potx, potm, odp, fodp, otp, doc, docx, docm, dot, dotx, dotm, odt, fodt, ott, rtf
